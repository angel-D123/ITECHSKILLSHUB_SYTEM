import { useState } from 'react';
import { Outlet, Link, useNavigate, useLocation } from 'react-router-dom';
import { 
  Home, Users, BookOpen, FileText, BarChart3, 
  Settings, LogOut, Bell, Menu, X 
} from 'lucide-react';
import './DashboardLayout.css';

export default function DashboardLayout({ userRole = 'admin' }) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const navigate = useNavigate();
  const location = useLocation();

  // Sidebar navigation items based on role
  const getNavigationItems = () => {
    if (userRole === 'admin') {
      return [
        { icon: Home, label: 'Dashboard', path: '/admin/dashboard' },
        { icon: Users, label: 'Users', path: '/admin/users' },
        { icon: BookOpen, label: 'Courses', path: '/admin/courses' },
        { icon: FileText, label: 'Assignments', path: '/admin/assignments' },
        { icon: BarChart3, label: 'Analytics', path: '/admin/analytics' },
        { icon: Settings, label: 'Settings', path: '/admin/settings' },
      ];
    } else if (userRole === 'instructor') {
      return [
        { icon: Home, label: 'Dashboard', path: '/instructor/dashboard' },
        { icon: BookOpen, label: 'My Courses', path: '/instructor/courses' },
        { icon: Users, label: 'Students', path: '/instructor/students' },
        { icon: FileText, label: 'Assignments', path: '/instructor/assignments' },
        { icon: BarChart3, label: 'Reports', path: '/instructor/reports' },
      ];
    }
    return [];
  };

  const handleLogout = () => {
    // TODO: Add logout logic
    navigate('/');
  };

  return (
    <div className="dashboard-layout">
      {/* Sidebar */}
      <aside className={`sidebar ${sidebarOpen ? 'open' : 'closed'}`}>
        <div className="sidebar-header">
          <h2>ITechSkills</h2>
          <button onClick={() => setSidebarOpen(!sidebarOpen)}>
            {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        <nav className="sidebar-nav">
          {getNavigationItems().map((item, index) => (
            <Link
              key={index}
              to={item.path}
              className={`nav-item ${location.pathname === item.path ? 'active' : ''}`}
            >
              <item.icon size={20} />
              {sidebarOpen && <span>{item.label}</span>}
            </Link>
          ))}
        </nav>

        <button className="logout-btn" onClick={handleLogout}>
          <LogOut size={20} />
          {sidebarOpen && <span>Logout</span>}
        </button>
      </aside>

      {/* Main Content */}
      <div className="main-content">
        {/* Top Navigation Bar */}
        <header className="top-nav">
          <button 
            className="menu-toggle"
            onClick={() => setSidebarOpen(!sidebarOpen)}
          >
            <Menu size={24} />
          </button>

          <div className="top-nav-right">
            <button className="notification-btn">
              <Bell size={20} />
              <span className="badge">3</span>
            </button>

            <div className="user-menu">
              <img 
                src="https://via.placeholder.com/40" 
                alt="User" 
                className="user-avatar"
              />
              <span className="user-name">Admin User</span>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="page-content">
          <Outlet />
        </main>
      </div>
    </div>
  );
}